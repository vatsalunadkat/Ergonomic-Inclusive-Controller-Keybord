package com.input.vatoobhai.ergonomickeybordcontroller;

public class Calculator {

    public int add(int a, int b){
        return (a+b);
    }

    public  float add(float a, float b){
        return (a+b);
    }

    public  float add(int a, float b){
        return (a+b);
    }





}
